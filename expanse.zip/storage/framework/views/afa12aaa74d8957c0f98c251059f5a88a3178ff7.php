<?php
    $role_id = auth()->user()->role_id;
    $users_active = true;
?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="ecommerce-widget">
        <div class="row">

            <div class="col-12 mb-4">
                <div class="card shadow-sm mb-5">
                    <h5 class="card-header"><?php echo e($role_id == 1 ? 'Company' : 'Employee'); ?> List</h5>
                    <div class="card-body">
                        <table class="table" id='myTable'>
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone Number</th>
                                    <?php if($role_id == 2): ?>
                                        <th scope="col">Role</th>
                                    <?php endif; ?>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $user_role = $user->role_id;
                                        $role = DB::table('roles')
                                            ->where('role_id', $user_role)
                                            ->first();
                                        $role = $role ? $role->role_name : 'unknown';

                                        $bg_color = $user_role == 3 ? 'bg-success' : ($user_role == 4 ? 'bg-secondary' : 'bg-danger');
                                    ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email ? $user->email : 'N/A'); ?></td>
                                        <td><?php echo e($user->phone_number ? $user->phone_number : 'N/A'); ?></td>
                                        <?php if($role_id == 2): ?>
                                            <th scope="col"> <span
                                                    class="badge text-light <?php echo e($bg_color); ?>"><?php echo e($role); ?></span> </th>
                                        <?php endif; ?>
                                        <td>
                                            <div class="dropdown show">
                                                <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    Action
                                                </a>

                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                    <a class="dropdown-item" href="<?php echo e(route('user.edit',Crypt::encrypt($user->id))); ?>">Edit</a>
                                                    
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\expanse\resources\views/common/user/index.blade.php ENDPATH**/ ?>