<?php
    $role_id = auth()->user()->role_id;
    $orders_active = true;
?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <div class="ecommerce-widget">
        <div class="row">

            <div class="col-12 mb-4">
                <div class="card shadow-sm mb-5">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <div>
                            <h5> Order List</h5>
                        </div>
                        <div>
                            <a href="<?php echo e(route('order.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Create
                                Order</a>
                        </div>

                    </div>
                    <div class="card-body">
                        <table class="table" id='myTable'>
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Customer Name</th>
                                    <?php if(auth()->user()->role_id == 2): ?>
                                        <th scope="col">Created By</th>
                                    <?php endif; ?>
                                    <th scope="col">Order Amount</th>
                                    <th scope="col">Created At</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                                        <td><?php echo e($order->customer_name); ?></td>
                                        <?php if(auth()->user()->role_id == 2): ?>
                                            <td> <a href=""><?php echo e($order->created_by); ?></a> </td>
                                        <?php endif; ?>
                                        <td><?php echo e($order->order_amount); ?></td>
                                        <td><?php echo e($order->created_at->format('d M Y')); ?></td>

                                        <td>
                                            <div class="dropdown show">
                                                <a class="btn btn-primary dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    Action
                                                </a>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                                    <a class="dropdown-item" href="<?php echo e(route('order.edit',Crypt::encrypt($order->id) )); ?>">Edit Details</a>
                                                    <a class="dropdown-item" href="<?php echo e(route('order.download',Crypt::encrypt($order->id) )); ?>">Download Invoice</a>
                                                    <a class="dropdown-item" href="<?php echo e(route('order.print',Crypt::encrypt($order->id) )); ?>">Print Invoice</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\expanse\resources\views/common/order/index.blade.php ENDPATH**/ ?>