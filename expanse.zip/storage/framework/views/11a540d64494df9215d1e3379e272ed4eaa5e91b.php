<li class="nav-item">
    <a class="nav-link <?php echo e(isset($dashboard_active)? 'active' : ''); ?>" href="/"><i class="fa fa-fw fa-user-circle"></i>Dashboard</a>
</li>
<li class="nav-item ">
    <a class="nav-link <?php echo e(isset($users_active)? 'active' : ''); ?>" href="#" data-toggle="collapse" aria-expanded="false" data-target="#company_sub_menu"
        aria-controls="company_sub_menu"><i class="fa fa-fw fa-user-circle"></i>Company</a>
    <div id="company_sub_menu" class="collapse submenu">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link " href="<?php echo e(route('user.create')); ?>">Create</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('user.index')); ?>">List</a>
            </li>
        </ul>
    </div>
</li>
<?php /**PATH D:\Laravel\expanse\resources\views/layouts/sidebars/admin-sidebar.blade.php ENDPATH**/ ?>