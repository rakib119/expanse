<?php
    $role_id = auth()->user()->role_id;
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>


    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">


    <!-- Libs CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/fullcalendar/main.min.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/quill/dist/quill.snow.css')); ?> ">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css')); ?>">
    <title> <?php echo $__env->yieldContent('page-title'); ?> <?php echo e(env('APP_NAME')); ?></title>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div class="dashboard-main-wrapper">
        <?php echo $__env->make('layouts.dashboard-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.sidebars.laft-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-wrapper">
            <div class="dashboard-ecommerce">
                <div class="container-fluid dashboard-content ">
                    <?php echo $__env->yieldContent('main-content'); ?>
                </div>
            </div>
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="copy-right col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <?php echo e(date('Y')); ?> © - All Right Reserved
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    <!-- Libs JS -->
    <script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if(session('success')): ?>
        <script>
              const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            Toast.fire({
                icon: 'success',
                title: '<?php echo e(session('success')); ?>',
            })
        </script>
    <?php endif; ?>
    <script>
        function succcessTost( message='success'){
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
            })
            Toast.fire({
                icon: 'success',
                title: message
            })
        }
    </script>
    <?php echo $__env->yieldContent('javascript'); ?>
</body>

</html>
<?php /**PATH D:\Laravel\expanse\resources\views/layouts/app.blade.php ENDPATH**/ ?>