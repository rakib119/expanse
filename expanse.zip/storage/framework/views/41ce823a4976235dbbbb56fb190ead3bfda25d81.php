<?php
    $expanses_active = true;
?>

<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class=" col-12">
            <div class="card mb-5 shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5> Add New Expanse Category</h5>
                    </div>
                    <div>
                        <a href="<?php echo e(route('category-expanse.index')); ?>" class="btn btn-secondary"> Expanse Category List <i
                                class="fa fa-arrow-right"></i></a>
                    </div>

                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('category-expanse.store')); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                        <div class="row align-items-end">

                            <div class="col-lg-6 col-sm-12 mb-3">
                                <label for="category" class="text-capitalize"> category <span>*</span></label>
                                <input required type="text" name="category"
                                    class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('category')); ?>"
                                    id="category" placeholder="Enter expanse category">
                                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"> <?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-lg-12 col-sm-12 mb-3">
                                <p class="text-left">
                                    <button type="reset" class="btn btn-space btn-secondary">Reset</button>
                                    <button type="submit" class="btn btn-space btn-primary">Submit</button>
                                </p>
                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\expanse\resources\views/company/expanse-category/create.blade.php ENDPATH**/ ?>