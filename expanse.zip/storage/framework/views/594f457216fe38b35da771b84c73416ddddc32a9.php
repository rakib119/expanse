<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css')); ?>">
    <title> <?php echo $__env->yieldContent('page-title'); ?></title>
</head>

<body class="bg-light">
    <div class="min-vh-100 d-flex align-items-center">
        <div class="splash-container">
            <div class="card shadow-sm">
                <div class="card-header text-center">
                    <a href="/"><img style="height: 50px;" class="logo-img" src="<?php echo e(asset('assets/images/logo.png')); ?>"
                            alt="logo"></a><span class="splash-description"><?php echo $__env->yieldContent('form-title'); ?></span>
                </div>
                <?php echo $__env->yieldContent('auth-content'); ?>
            </div>
        </div>
    </div>
      <!-- Theme JS -->
  <script src=" <?php echo e(asset('assets/js/theme.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\Laravel\expanse\resources\views/auth/auth-layout.blade.php ENDPATH**/ ?>