<div class="dashboard-header">
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
        <a class="navbar-brand" href="/"><img width="155" height="30" src="<?php echo e(asset('assets/images/logo.png')); ?>"
                alt=""></a>
        <div class="ml-auto" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto navbar-right-top flex-row ">
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item dropdown nav-user order-lg-4 ">
                        <a class="nav-link nav-user-img') }}" href="#" id="navbarDropdownMenuLink2"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img
                                src="<?php echo e(asset('assets/images/profile/' . auth()->user()->profile_photo)); ?>" alt=""
                                class="avatar-xs rounded-circle"></a>

                        <div class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                            aria-labelledby="navbarDropdownMenuLink2">

                            <div class="nav-user-info">
                                <h5 class="mb-0 text-white nav-user-name"><?php echo e(auth()->user()->name); ?></h5>
                            </div>
                            <a class="dropdown-item" href="<?php echo e(route('password.change')); ?>"><i class="fas fa-power-off mr-2"></i>Change Password</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i
                                    class="fas fa-power-off mr-2"></i>Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</div>
<?php /**PATH D:\Laravel\expanse\resources\views/layouts/dashboard-header.blade.php ENDPATH**/ ?>